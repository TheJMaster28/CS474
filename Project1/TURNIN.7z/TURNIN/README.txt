To run program, run the command `make run_once` to compile and run the test once.

To run muliple tests after each other, run the command `make` or `make run`



